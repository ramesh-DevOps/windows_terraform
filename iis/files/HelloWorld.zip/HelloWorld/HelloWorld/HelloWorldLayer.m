//
//  HelloWorldLayer.m
//  HelloWorld
//
//  Created by Sagar R Kothari on 11/28/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

//Hello All ! I am going to illustrate following points using this video.
//
//1. Scheduling a method
//2. Unscheduling a method
//
//Some Basic Action :)
//3. CCMoveTo
//4. CCReverse
//5. CCMoveBy
//6. CCSequence
//
//So, we can access label in any of the - minus method of the class :)

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
		
		// create and initialize a Label
		label = [CCLabelTTF labelWithString:@"Hello World" fontName:@"Marker Felt" fontSize:64];

		// ask director the the window size
		CGSize size = [[CCDirector sharedDirector] winSize];
	
		// position the label on the center of the screen
		label.position =  ccp( size.width /2 , size.height/2 );
		
		// add the label as a child to this Layer
		[self addChild: label];
        
        //we are going to schedule a method
        // to schedule a method use following line of code
        // below code will schedule & which will be called after every one second.
        [self schedule:@selector(moveByBottom) interval:0.5];
	}
	return self;
}

- (void)moveByBottom {
//    [self unschedule:@selector(moveByBottom)]; 
    CGSize size = [[CCDirector sharedDirector] winSize];
    
    //CCMoveBy to requires location modification based on current location of object
    
    id action = [CCMoveBy actionWithDuration:0.25 position:ccp(0, (label.contentSize.height/2-size.height/2))];
    
    // ccMoveBy supports reverse :)
    
    id actionReve = [action reverse];
    
    [label runAction:[CCSequence actions:action,actionReve, nil]];
    
    // did ya got it ?
    
    // ok that is it for today ! Thax for viewing this video :)
}

- (void)moveToBottom {
    // as you can notice bla bla after each second.
    // so unschedule a method, use following line of code.
    // so this method will be executed once only :)
//    [self unschedule:@selector(moveToBottom)]; 
    
    CGSize size = [[CCDirector sharedDirector] winSize];

    // determine the exact location in window where you want to move your label.
    // it means exact co-ordinate of label where you want to place it.
    // in moveTo we have to specify the location where we want to move it.
    
    // this line of code will generate an move to action & 
    // we will have a reference of that action in moveTo variable
    id moveTo=[CCMoveTo actionWithDuration:0.25 position:ccp(size.width /2,label.contentSize.height/2)];
    id moveTo2=[CCMoveTo actionWithDuration:0.25 position:ccp(size.width /2,size.height-label.contentSize.height/2)];
    
    // remember MoveTo does not support reverse
    // if you try to reverse MoveTo action - app will get crashed 
    
    // what if I want to run two different actions,
    // use sequence for that :)
    id seq = [CCSequence actions:moveTo,moveTo2, nil];
    
    [label runAction:seq];
    
    // as you can notice label moving up & down :)
    
    // we are going to implement the same things
    // but using CCMoveBy in next Function :)
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
